from fetch_kbo import Parse,prefix
import urllib.request,urllib.parse,http.cookiejar,json,re,concurrent.futures
from pathlib import Path
root=Path('/workspace/scratch/159de331a77b/baseball-sources');root.mkdir(exist_ok=True)
def get(url,data=None):
 for attempt in range(3):
  try:return urllib.request.urlopen(url,urllib.parse.urlencode(data).encode() if data else None,timeout=40).read().decode()
  except Exception:
   if attempt==2:raise

def kbo(kind,sort):
 op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def get(url,data=None):return op.open(url,urllib.parse.urlencode(data).encode() if data else None,timeout=40).read().decode()
 url='https://www.koreabaseball.com/Record/Player/'+kind+'/Basic.aspx';h=get(url);rows=[];seen=set()
 def post(h,event):
  f=Parse(h).fields;f[prefix+'ddlSeason$ddlSeason']='2025';f[prefix+'hfOrderByCol']=sort;f[prefix+'hfOrderBy']='DESC';f['__EVENTTARGET']=event;f['__EVENTARGUMENT']='';return get(url,f)
 h=post(h,prefix+'lbtnOrderBy')
 for n in range(30):
  p=Parse(h);current=re.search(r'id="[^"]+ucPager_btnNo(\d+)" class="on"[^>]*>(\d+)</a>',h)
  page=int(current[2]) if current else 1
  if page in seen:break
  seen.add(page);rows+=p.rows[1:];print(kind,page,len(rows),flush=True)
  Path(root/(kind+'2025.json')).write_text(json.dumps({'year':2025,'source':url,'headers':p.rows[0],'rows':rows},ensure_ascii=False))
  link=next((x for x in p.links if ('ucPager$btnNo'+str((page%5)+1)) in x),None) if page%5 else next((x for x in p.links if 'ucPager$btnNext' in x),None)
  if not link:break
  h=post(h,re.search(r"__doPostBack\('([^']+)'",link)[1])
 return kind,len(rows)
def raw(name,url,data=None):
 h=get(url,data);(root/name).write_text(h);print(name,len(h),flush=True);return name,len(h)
jobs=[lambda:kbo('Runner','SB_CN')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for r in ex.map(lambda fn:fn(),jobs):print('DONE',r,flush=True)
